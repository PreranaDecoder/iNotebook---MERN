import connectToMongo from './db.js';
import express from 'express';

connectToMongo();
const app = express();
const port = 3000;

//Available routes

// app.get('/', (req, res) => {
//   res.send('Hello PRB!');
// });
app.get('/api/auth', require('./routes/auth'))
app.get('/api/notes', require('./routes/notes'))

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
